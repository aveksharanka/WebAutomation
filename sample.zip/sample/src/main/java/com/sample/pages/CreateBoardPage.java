package com.sample.pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CreateBoardPage extends BasePage {

	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(90));

	public CreateBoardPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(name = "name")
	private WebElement listName;

	@FindBy(xpath = "//input[@value='Add list']")
	private WebElement addListBtn;

	@FindBy(className = "js-add-a-card")
	private WebElement addCardBtn;

	@FindBy(xpath = "//textarea[@class='list-card-composer-textarea js-card-title']")
	private WebElement addCardText;

	@FindBy(xpath = "//input[@value='Add card']")
	private WebElement saveCard;

	@FindBy(xpath = "//div[@class='list-card-details js-card-details']")
	private WebElement sourceElement;

	@FindBy(xpath = "//a[@class='open-card-composer js-open-card-composer']")
	private WebElement targetElement;

	@FindBy(xpath = "//span[@class='list-card-title js-card-name']")
	private WebElement movedCardPosition;

	public void createList() {
		wait.until(ExpectedConditions.visibilityOf(listName));
		listName.sendKeys("List A");
		addListBtn.click();
		listName.sendKeys("List B");
		addListBtn.click();
	}

	public void addCard() {
		addCardBtn.click();
		wait.until(ExpectedConditions.visibilityOf(addCardText));
		addCardText.sendKeys("Card A");
		saveCard.click();
	}

	public void dragAndDropCard() {
		Actions actions = new Actions(driver);
		actions.dragAndDrop(sourceElement, targetElement).build().perform();
	}

	public void getCoordinates() throws InterruptedException {
		int xCoordinate = movedCardPosition.getLocation().getX();
		int yCoordinate = movedCardPosition.getLocation().getY();

		System.out.println("Moved card coordinates: X=" + xCoordinate + ", Y=" + yCoordinate);
	}
}
