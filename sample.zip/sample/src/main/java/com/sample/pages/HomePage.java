package com.sample.pages;

import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HomePage extends BasePage {
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(90));
	
	@FindBy(xpath = "//button[@data-testid='header-create-menu-button']")
	private WebElement createMenuBtn;

	@FindBy(xpath = "//button[@data-testid='header-create-board-button']")
	private WebElement createBoard;

	@FindBy(xpath = "//button[@data-testid='create-board-submit-button']")
	private WebElement createBtn;

	@FindBy(xpath = "//input[@data-testid='create-board-title-input']")
	private WebElement boardTitle;

	public HomePage(WebDriver driver) {
		super(driver);
	}

	public void createBoard() throws InterruptedException {
		wait.until(ExpectedConditions.visibilityOf(createMenuBtn));
		createMenuBtn.click();
		wait.until(ExpectedConditions.visibilityOf(createBoard));
		createBoard.click();
		boardTitle.sendKeys("Project Dashboard");
		wait.until(ExpectedConditions.visibilityOf(createBtn));
//		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", createBtn);
		createBtn.click();
	}
}
