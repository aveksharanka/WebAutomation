package com.sample.pages;


import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LogOutPage extends BasePage {
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(90));
	public LogOutPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(xpath = "//button[@data-testid='header-member-menu-button']")
	private WebElement userProfile;

	@FindBy(xpath = "//button[@data-testid='account-menu-logout']")
	private WebElement logOutBtn;
	
	@FindBy(id = "logout-submit")
	private WebElement emailIdField;
	
	
	public void LogOut() {
		userProfile.click();
		wait.until(ExpectedConditions.visibilityOf(logOutBtn));
		logOutBtn.click();
	}
}
