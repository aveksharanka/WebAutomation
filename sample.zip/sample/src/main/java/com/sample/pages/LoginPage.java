package com.sample.pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage extends BasePage {
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(90));

	public LoginPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(id = "user")
	private WebElement emailIdField;

	@FindBy(id = "login")
	private WebElement continueBtn;

	@FindBy(id = "password")
	private WebElement passwordField;

	@FindBy(id = "login-submit")
	private WebElement submitBtn;

	public void login() throws InterruptedException {
		emailIdField.sendKeys("demotrello1@gmail.com");
		continueBtn.click();
		wait.until(ExpectedConditions.visibilityOf(passwordField));
		passwordField.sendKeys("Trello123$");
		submitBtn.click();
	}
}