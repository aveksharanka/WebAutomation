package com.sample.tests;

import org.testng.annotations.Test;

import com.sample.pages.CreateBoardPage;
import com.sample.pages.HomePage;
import com.sample.pages.LogOutPage;
import com.sample.pages.LoginPage;

public class TrelloTest extends BaseTest {
	@Test
	public void Test() throws InterruptedException {
		driver.get("https://trello.com/en/login");
		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = new HomePage(driver);
		CreateBoardPage createBoardPage = new CreateBoardPage(driver);
		LogOutPage logOutPage = new LogOutPage(driver);
		loginPage.login();
		homePage.createBoard();
		createBoardPage.createList();
		createBoardPage.addCard();
		createBoardPage.dragAndDropCard();
		createBoardPage.getCoordinates();
		logOutPage.LogOut();
	}
}
